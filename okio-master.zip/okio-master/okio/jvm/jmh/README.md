Okio Benchmarks
===============

This module contains JMH microbenchmarks. Run benchmarks locally with Gradle:

```
$ ./gradlew jmh
```

Select and configure benchmarks in the `jmh` section of `okio/jvm/jmh/build.gradle`.
