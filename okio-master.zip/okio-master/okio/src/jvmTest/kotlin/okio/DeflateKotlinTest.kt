/*
 * Copyright (C) 2018 Square, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package okio

import okio.ByteString.Companion.decodeHex
import org.junit.Test
import java.util.zip.Deflater
import java.util.zip.Inflater
import kotlin.test.assertEquals

class DeflateKotlinTest {
  @Test fun deflate() {
    val data = Buffer()
    val deflater = (data as Sink).deflate()
    deflater.buffer().writeUtf8("Hi!").close()
    assertEquals("789cf3c854040001ce00d3", data.readByteString().hex())
  }

  @Test fun deflateWithDeflater() {
    val data = Buffer()
    val deflater = (data as Sink).deflate(Deflater(0, true))
    deflater.buffer().writeUtf8("Hi!").close()
    assertEquals("010300fcff486921", data.readByteString().hex())
  }

  @Test fun inflate() {
    val buffer = Buffer().write("789cf3c854040001ce00d3".decodeHex())
    val inflated = (buffer as Source).inflate()
    assertEquals("Hi!", inflated.buffer().readUtf8())
  }

  @Test fun inflateWithInflater() {
    val buffer = Buffer().write("010300fcff486921".decodeHex())
    val inflated = (buffer as Source).inflate(Inflater(true))
    assertEquals("Hi!", inflated.buffer().readUtf8())
  }
}
